from pathlib import Path
import os,sys,json,subprocess,shutil,tempfile,time,hashlib,signal,zipfile
repo=Path('/Users/serge/.t3/worktrees/openergy/t3-52422617')
root=Path(tempfile.mkdtemp(prefix='oe-priority-package-',dir='/private/tmp'))
os.chmod(root,0o700)
(root/'controller.py').write_bytes(Path(__file__).read_bytes())
Path('/tmp/oe-priority-package-state.json').write_text(json.dumps({'root':str(root),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()})+'\n')
os.setpriority(os.PRIO_PROCESS,0,15)
assert os.getpriority(os.PRIO_PROCESS,0)==15
print('Private packaging root:',root,flush=True)
def write(name,obj): (root/name).write_text(json.dumps(obj,indent=2)+'\n')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
sources={n:digest(repo/n) for n in files if n and not n.startswith(('docs/verification/','.git')) and (repo/n).is_file()}
write('source-inputs.json',sources)
cache=Path(json.loads(Path('/tmp/oe-sparkle-combined-20261023-state.json').read_text())['root'])
def inventory(base):
 out={}
 for p in sorted(base.rglob('*')):
  if p.is_symlink(): out[str(p.relative_to(base))]={'link':os.readlink(p)}
  elif p.is_file(): out[str(p.relative_to(base))]={'sha256':digest(p),'bytes':p.stat().st_size}
 return out
before={n:inventory(cache/n) for n in ['swift','cargo']}
write('cache-before.json',before)
for name in ['home','tmp','cargo-home','xdg','module-cache']: (root/name).mkdir(mode=0o700)
for name in ['swift','cargo']:
 subprocess.run(['/bin/cp','-cR',str(cache/name),str(root/name)],check=True)
subprocess.run(['/bin/cp','-cR',str(Path.home()/'.cargo/registry'),str(root/'cargo-home/registry')],check=True)
write('cache-copy.json',{n:inventory(root/n) for n in ['swift','cargo']})
# Use only explicit nonsecret runtime/build inputs; no signing identity lookup.
env={k:os.environ[k] for k in ['PATH','LANG','LC_ALL','DEVELOPER_DIR','SDKROOT','SYSTEMROOT'] if k in os.environ}
env.update(PATH='/Users/serge/.cargo/bin:'+env.get('PATH','/usr/bin:/bin:/usr/sbin:/sbin'),HOME=str(root/'home'),CFFIXED_USER_HOME=str(root/'home'),TMPDIR=str(root/'tmp')+'/',XDG_CACHE_HOME=str(root/'xdg'),CARGO_HOME=str(root/'cargo-home'),RUSTUP_HOME='/Users/serge/.rustup',RUSTUP_TOOLCHAIN='1.99.1',CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(root/'cargo'),SWIFT_SCRATCH_PATH=str(root/'swift'),CLANG_MODULE_CACHE_PATH=str(root/'module-cache'),SWIFTPM_MODULECACHE_OVERRIDE=str(root/'module-cache'),PYTHON='/Users/serge/.local/bin/python3.11',MACOSX_DEPLOYMENT_TARGET='15.0',OPENERGY_BUILD='3',OPENERGY_REQUIRE_UPDATES='1',OPENERGY_SIGN_IDENTITY='-')
args=[env['PYTHON'],str(repo/'tools/release/release.py'),'package','--port-range','65310-65319','--output',str(root/'output')]
write('plan.json',{'args':args,'env':env,'controller_nice':os.getpriority(os.PRIO_PROCESS,0),'runtime':'real staged and extracted off-role virtual daemon IPC; no app launch','attempts':1,'timeout_seconds':900,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()})
(root/'package-once.guard').write_text('one package invocation\n')
start=time.monotonic();samples=[];known={};timed_out=False
with (root/'package.stdout').open('w') as out,(root/'package.stderr').open('w') as err:
 p=subprocess.Popen(args,cwd=repo,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 while p.poll() is None:
  rows=subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,ni=,comm='],text=True).splitlines()
  table={}
  for row in rows:
   a=row.strip().split(None,3)
   if len(a)==4:
    try: table[int(a[0])]={'pid':int(a[0]),'ppid':int(a[1]),'nice':int(a[2]),'comm':a[3]}
    except ValueError: pass
  owned={p.pid}
  while True:
   new=owned|{pid for pid,r in table.items() if r['ppid'] in owned}
   if new==owned: break
   owned=new
  observed=[table[pid] for pid in sorted(owned) if pid in table]
  for r in observed: known[r['pid']]=r
  samples.append({'elapsed':time.monotonic()-start,'owned':observed})
  if time.monotonic()-start>900:
   timed_out=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   break
  time.sleep(.1)
 p.wait()
write('process-samples.json',samples)
write('package-result.json',{'exit':p.returncode,'elapsed_seconds':time.monotonic()-start,'timeout':timed_out,'root_pid':p.pid,'stdout_sha256':digest(root/'package.stdout'),'stderr_sha256':digest(root/'package.stderr')})
after={n:inventory(cache/n) for n in ['swift','cargo']};write('cache-after.json',after)
source_same=all(digest(repo/n)==h for n,h in sources.items())
remaining=[]
for pid,r in known.items():
 q=subprocess.run(['/bin/ps','-p',str(pid),'-o','pid=,ppid=,ni=,comm='],text=True,capture_output=True)
 if q.returncode==0: remaining.append({'old':r,'current':q.stdout.strip()})
write('postflight.json',{'cached_inputs_unchanged':before==after,'source_inputs_unchanged':source_same,'observed_pids_still_present':remaining,'all_observed_nice_15':all(r['nice']==15 for s in samples for r in s['owned']),'samples':len(samples),'observed_processes':len(known)})
artifacts=[]
if (root/'output').exists():
 for f in sorted((root/'output').iterdir()):
  if f.is_file(): artifacts.append({'path':str(f),'sha256':digest(f),'bytes':f.stat().st_size})
write('artifacts.json',artifacts)
print(json.dumps({'root':str(root),'exit':p.returncode,'elapsed_seconds':time.monotonic()-start,'source_same':source_same,'cache_same':before==after,'remaining_observed_pids':len(remaining),'artifacts':artifacts}),flush=True)
if p.returncode: print('\n'.join((root/'package.stderr').read_text().splitlines()[-14:]),flush=True)
sys.exit(p.returncode)
